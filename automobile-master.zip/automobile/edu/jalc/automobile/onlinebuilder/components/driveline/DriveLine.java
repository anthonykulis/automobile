package edu.jalc.automobile.onlinebuilder.components.driveline;

import edu.jalc.automobile.onlinebuilder.components.Component;

public abstract class DriveLine extends Component{

  }

package edu.jalc.automobile.onlinebuilder.components;

abstract public class Component {
}

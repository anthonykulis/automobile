Readme.md
Here is our UML
https://www.lucidchart.com/invitations/accept/265211af-ac36-4560-aad4-8065b7f8c99d

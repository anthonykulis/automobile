package edu.jalc.automobile.onlinebuilder.components.engine;

import edu.jalc.automobile.onlinebuilder.components.Component;

abstract public class EngineAssembly extends Component {
}

package edu.jalc.automobile.onlinebuilder.components.suspension;

import edu.jalc.automobile.onlinebuilder.components.Component;

public abstract class Suspension extends Component {


}

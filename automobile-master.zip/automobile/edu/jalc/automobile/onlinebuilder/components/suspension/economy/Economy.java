package edu.jalc.automobile.onlinebuilder.components.suspension.economy;

import edu.jalc.automobile.onlinebuilder.components.suspension.Suspension;

abstract class Economy extends Suspension {

}

package edu.jalc.automobile.onlinebuilder.components.suspension.sport;

import edu.jalc.automobile.onlinebuilder.components.suspension.Suspension;

abstract class Sport extends Suspension {

}

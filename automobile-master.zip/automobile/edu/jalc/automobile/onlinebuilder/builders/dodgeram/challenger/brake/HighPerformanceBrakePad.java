package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.brake;

public class HighPerformanceBrakePad{

  private String description;

  public void HighPerformanceBrakePad(String description){
  this.description = description;
  }

  public String toString(){
    return this.description + "High Performance Brake Pad";
  }

  }

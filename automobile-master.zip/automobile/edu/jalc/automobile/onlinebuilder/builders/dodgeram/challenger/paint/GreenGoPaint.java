package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class GreenGoPaint extends Paint{

  public GreenGoPaint(){
  }

  public String toString(){
    return "Green Go Paint";
  }

}
package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

abstract public class Paint{

  public Paint(){
  }

}
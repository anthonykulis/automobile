package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger;

public class DodgeChallengerSXTBuilder implements DodgeRamBuilderInterface{
   
   private EngineAssembly engineAssembly;
   
   DodgeRamBuilderInterface askForPowerTrain(TerminalPrompterBuilderInterface promptBuilder){
      Engine engine = new VVT24ValveSportEngine(3.6, new HorsePower(303,3000), new Torque(300,2000), 6);
      EngineAssembly engineAssembly = new NaturallyAspiratedSportEngine(engine, new PerformanceExhaust(), new NaturallyAspiratedInduction());
      promptBuilder.addtype("Powertrain")
         .addOption(engineAssembly)
         .build()
         .tell("Your SXT Comes With A " + engineAssembly);
      this.engineAssembly = engineAssembly;
      return this;
   }

   DodgeRamBuilderInterface askForColorAndInterior(TerminalPrompterBuilderInterface promptBuilder){
      return this;
   }


	DodgeRamBuilderInterface askForOptions(TerminalPrompterBuilderInterface promptBuilder){
      return this;
   }

	DodgeRamBuilderInterface askForPackages(TerminalPrompterBuilderInterface promptBuilder){
      return this;
   }

	Automobile build(){
      return new Automobile("Dodge","Challenger","SXT",null,null,this.engineAssembly,null);
   }

}
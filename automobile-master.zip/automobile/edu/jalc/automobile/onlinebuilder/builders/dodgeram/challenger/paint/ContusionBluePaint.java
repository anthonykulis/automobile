package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class ContusionBluePaint extends Paint{

  public ContusionBluePaint(){
  }

  public String toString(){
    return "Contusion Blue Paint";
  }

}
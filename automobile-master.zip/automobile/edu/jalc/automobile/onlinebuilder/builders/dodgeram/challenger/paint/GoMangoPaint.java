package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class GoMangoPaint extends Paint{

  public GoMangoPaint(){
  }

  public String toString(){
    return "Go Mango Paint";
  }

}
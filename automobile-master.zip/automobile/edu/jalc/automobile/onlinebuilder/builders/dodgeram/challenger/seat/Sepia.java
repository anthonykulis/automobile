package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.seat;

public class Sepia extends Color{

  public String toString(){
    return("Sepia");
  }
}

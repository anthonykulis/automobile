package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class MaximumSteelPaint extends Paint{

  public MaximumSteelPaint(){
  }

  public String toString(){
    return "Maximum Steel Paint";
  }

}
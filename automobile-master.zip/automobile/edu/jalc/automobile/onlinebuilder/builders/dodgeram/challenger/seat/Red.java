package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.seat;

public class Red extends Color{

  public String toString(){
    return("Red");
  }
}

package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class PitchBlackPaint extends Paint{

  public PitchBlackPaint(){
  }

  public String toString(){
    return "Pitch Black Paint";
  }

}
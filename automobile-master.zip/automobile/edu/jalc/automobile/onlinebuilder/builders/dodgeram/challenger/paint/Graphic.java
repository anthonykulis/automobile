package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class Graphic{

  private String name;

  public Graphic(String name){
    this.name = name;
  }

  public String toString(){
    return "Graphic: " + this.name;
  }

}
package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.seat;

public class Black extends Color{

  public String toString(){
    return("Black");
  }
}

package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class OctaneRedPaint extends Paint{

  public OctaneRedPaint(){
  }

  public String toString(){
    return "Octane Red Paint";
  }

}
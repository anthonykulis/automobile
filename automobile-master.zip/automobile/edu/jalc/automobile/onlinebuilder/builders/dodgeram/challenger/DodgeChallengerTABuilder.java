package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger;

import edu.jalc.automobile.onlinebuilder.builders.dodgeram.DodgeRamBuilderInterface;
import edu.jalc.automobile.Automobile;
import edu.jalc.automobile.common.utils.prompter.TerminalPrompterBuilderInterface;
import edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.brake*;
import edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.engine.HemiVvtSportEngine;
import edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.engine.HemiMdsVvtSportEngine;
//import color
//import graphic
import edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.seat.ClothBucketSeat;
import


public class DodgeChallengerTABuilder implements DodgeRamBuilderInterface{

  askForPowerTrain(){

  }
}

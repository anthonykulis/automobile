package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.engine;

import edu.jalc.automobile.parts.engine.SportEngine;

public class VVTSportEngine extends SportEngine{

   public VVTSportEngine(double displacement, HorsePower horsePower, Torque torque, int cylinders){
      super(displacement,horsePower,torque,cylinders);
   }

}
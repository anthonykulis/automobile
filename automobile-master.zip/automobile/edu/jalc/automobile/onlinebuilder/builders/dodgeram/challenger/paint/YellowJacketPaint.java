package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.paint;

public class YellowJacketPaint extends Paint{

  public YellowJacketPaint(){
  }

  public String toString(){
    return "Yellow Jacket Paint";
  }

}
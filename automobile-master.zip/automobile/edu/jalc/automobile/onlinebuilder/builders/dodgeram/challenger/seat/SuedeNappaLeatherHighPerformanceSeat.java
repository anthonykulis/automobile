package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.seat;

import edu.jalc.automobile.parts.body.seat.LeatherSeat;

public class SuedeNappaLeatherHighPerformanceSeat extends LeatherSeat{

  public SuedeNappaLeatherHighPerformanceSeat(){
  }
  
  public String toString(){
    return "Suede / Nappa Leather High Performance Seats";
  }

}
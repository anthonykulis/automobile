package edu.jalc.automobile.onlinebuilder.builders.dodgeram.challenger.seat;

abstract public class Color{

}

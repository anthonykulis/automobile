package edu.jalc.automobile.parts.driveline;

public class RearDeadAxle{

   public String toString(){
      return "RearDeadAxle";
   }
}
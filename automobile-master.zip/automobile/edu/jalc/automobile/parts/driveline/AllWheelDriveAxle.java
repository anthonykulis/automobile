package edu.jalc.automobile.parts.driveline;

public class AllWheelDriveAxle{

  public String toString(){
    return "AllWheelDriveAxle";
  }
}

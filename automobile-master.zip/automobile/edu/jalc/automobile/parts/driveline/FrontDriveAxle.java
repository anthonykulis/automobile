package edu.jalc.automobile.parts.driveline;

public class FrontDriveAxle{

   public String toString(){
      return "FrontDriveAxle";
   }
}
package edu.jalc.automobile.parts.driveline;

public class ElectricSteering{

   public String toString(){
      return "ElectricSteering";
   }
}
package edu.jalc.automobile.parts.driveline;

public class LockingDifferential{

   public String toString(){
      return "LockingDifferential";
   }
}
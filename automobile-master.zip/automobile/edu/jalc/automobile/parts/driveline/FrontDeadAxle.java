package edu.jalc.automobile.parts.driveline;

public class FrontDeadAxle{

   public String toString(){
      return "FrontDeadAxle";
   }
}
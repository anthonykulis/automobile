package edu.jalc.automobile.parts.driveline;

public class DriveShaft{

   public String toString(){
      return "DriveShaft";
   }
}
package edu.jalc.automobile.parts.driveline;

public class HydraulicSteering{

  public String toString(){
    return "HydraulicSteering";
  }
}

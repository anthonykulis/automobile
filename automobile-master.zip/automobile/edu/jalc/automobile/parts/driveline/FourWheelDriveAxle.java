package edu.jalc.automobile.parts.driveline;

public class FourWheelDriveAxle{

   public String toString(){
      return "FourWheelDriveAxle";
   }
}
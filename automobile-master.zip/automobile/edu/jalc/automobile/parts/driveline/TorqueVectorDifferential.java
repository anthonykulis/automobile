package edu.jalc.automobile.parts.driveline;

public class TorqueVectorDifferential{

  public String toString(){
    return "TorqueVectorDifferential";
  }
}

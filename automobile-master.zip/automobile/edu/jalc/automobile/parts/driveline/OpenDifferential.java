package edu.jalc.automobile.parts.driveline;

public class OpenDifferential{

   public String toString(){
      return "OpenDifferential";
   }
}
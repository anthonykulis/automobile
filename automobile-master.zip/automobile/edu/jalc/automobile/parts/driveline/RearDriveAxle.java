package edu.jalc.automobile.parts.driveline;

public class RearDriveAxle{

   public String toString(){
      return "RearDriveAxle";
   }
}
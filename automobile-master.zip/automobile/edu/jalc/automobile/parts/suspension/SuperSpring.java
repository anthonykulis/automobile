package edu.jalc.automobile.parts.suspension;

public class SuperSpring extends Spring{



   public SuperSpring(double height){
      super(height);
   }

   public String toString(){
      return getHeight() + "in Super Coil Spring";
   }
}
   
package edu.jalc.automobile.parts.suspension;

public class StockSpring extends Spring{

   public StockSpring(double height){
      super(height);
   }

   
   public String toString(){
      return "Stock Coil Spring";
   }
}
   
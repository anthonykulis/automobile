package edu.jalc.automobile.parts.suspension;

public class StockShock extends Shock{

   public StockShock(double height){ super(height); }
   public String toString(){
      return "Stock Shock";
   }
}
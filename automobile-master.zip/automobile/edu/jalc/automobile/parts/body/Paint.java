package edu.jalc.automobile.parts.body;

public class Paint{
   private String name;

   public Paint(){

   }


   public String toString(){
      return "Paint is :\n" +
                        "\t"+name;
   }
}

package edu.jalc.automobile.parts.body;

public class Graphic{
  private String name;

  public Graphic(){
  }

  public String toString(){
    return "Graphic: " + this.name;
  }
}

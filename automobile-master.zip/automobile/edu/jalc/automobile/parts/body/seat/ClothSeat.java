package edu.jalc.automobile.parts.body.seat;

public class ClothSeat extends Seat {

  public String toString(){
    return "ClothSeat Seat";
  }
}

package edu.jalc.automobile.parts.body.seat;


public class Seat {

}
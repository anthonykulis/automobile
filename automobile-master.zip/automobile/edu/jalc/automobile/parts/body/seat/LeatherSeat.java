package edu.jalc.automobile.parts.body.seat;

public class LeatherSeat extends Seat {

  public String toString(){
    return "LeatherSeat Seat";
  }
}

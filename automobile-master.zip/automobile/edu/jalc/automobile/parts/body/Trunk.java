package edu.jalc.automobile.parts.body;

abstract public class Trunk{
  double cubicFt;
  abstract public double getCubicFt();




}

package edu.jalc.automobile.parts.body;

public class Hatchback extends Trunk{

  public Hatchback(double cubicFt){super.cubicFt = cubicFt;}

  public double getCubicFt(){return super.cubicFt;}
  public String toString(){
    return "Hacthback";
  }
}

package edu.jalc.automobile.parts.body;

public class LongBed extends TruckBed{

public LongBed(double cubicFt){super.cubicFt = cubicFt;}

public double getCubicFt(){return super.cubicFt;}
  public String toString(){
    return "LongBed";
  }



}

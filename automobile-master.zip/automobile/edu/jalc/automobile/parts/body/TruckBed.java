package edu.jalc.automobile.parts.body;

abstract public class TruckBed{
  double cubicFt;
  abstract public double getCubicFt();



}

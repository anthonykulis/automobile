package edu.jalc.automobile.parts.induction;
public class NaturallyAspiratedInduction extends Induction{
  public String toString(){
    return "naturally aspirated induction";
  }
}

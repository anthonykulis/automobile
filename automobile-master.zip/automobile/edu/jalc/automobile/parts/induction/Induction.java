package edu.jalc.automobile.parts.induction;
abstract public class Induction{
}

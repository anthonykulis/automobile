package edu.jalc.automobile.parts.induction;
public class TurbochargedInduction extends BoostedInduction{
  public String toString(){
    return "turbocharged induction";
  }
}

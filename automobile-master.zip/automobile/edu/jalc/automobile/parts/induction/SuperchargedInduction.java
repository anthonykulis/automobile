package edu.jalc.automobile.parts.induction;
public class SuperchargedInduction extends BoostedInduction{
  public String toString(){
    return "supercharged induction";
  }
}

package edu.jalc.automobile.parts.exhaust;
public class EconomyExhaust extends Exhaust{
  public String toString(){
    return "economy exhaust";
  }
}

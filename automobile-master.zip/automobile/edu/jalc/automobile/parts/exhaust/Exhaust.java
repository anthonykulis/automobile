package edu.jalc.automobile.parts.exhaust;
abstract public class Exhaust{
   abstract public String toString();
}

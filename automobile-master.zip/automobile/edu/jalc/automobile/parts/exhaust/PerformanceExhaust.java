package edu.jalc.automobile.parts.exhaust;
public class PerformanceExhaust extends Exhaust{
  public String toString(){
    return "performance exhaust";
  }
}

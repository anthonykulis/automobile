package edu.jalc.automobile.common.utils.prompter;

public interface Askable {
	public int ask();
}

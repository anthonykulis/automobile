package edu.jalc.automobile.common.utils.prompter;

public interface Tellable {
	public void tell(String message);
}
